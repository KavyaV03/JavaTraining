package com.dal.rmq.rabbdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
