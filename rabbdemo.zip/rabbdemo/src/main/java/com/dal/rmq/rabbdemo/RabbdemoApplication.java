package com.dal.rmq.rabbdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RabbdemoApplication.class, args);
	}

}
